package com.tka.models;

public enum OrderStatusValues {
	SUCCESS,PENDING,CANCELLED
}
