package com.tka.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tka.exception.CategoryNotFoundException;
import com.tka.exception.ProductNotFoundException;
import com.tka.models.CategoryEnum;
import com.tka.models.Product;
import com.tka.models.ProductDTO;
import com.tka.models.ProductStatus;
import com.tka.models.Seller;
import com.tka.repository.ProductDao;
import com.tka.repository.SellerDao;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductDao prodDao;

	@Autowired
	private SellerService sService;

	@Autowired
	private SellerDao sDao;

	// ADD PRODUCT
	@Override
	public Product addProductToCatalog(String token, Product product) {

		Seller seller1 = sService.getCurrentlyLoggedInSeller(token);
		product.setSeller(seller1);

		Seller existingSeller = sService.getSellerByMobile(product.getSeller().getMobile(), token);
		Optional<Seller> opt = sDao.findById(existingSeller.getSellerId());

		if (opt.isPresent()) {
			Seller seller = opt.get();
			product.setSeller(seller);

			Product savedProd = prodDao.save(product);

			seller.getProduct().add(savedProd);
			sDao.save(seller);

			return savedProd;

		} else {
			return prodDao.save(product);
		}
	}

	// GET PRODUCT BY ID
	@Override
	public Product getProductFromCatalogById(Integer id) throws ProductNotFoundException {

		return prodDao.findById(id)
				.orElseThrow(() -> new ProductNotFoundException("Product not found with given id"));
	}

	// DELETE PRODUCT
	@Override
	public String deleteProductFromCatalog(Integer id) throws ProductNotFoundException {
		Optional<Product> opt = prodDao.findById(id);

		if (opt.isPresent()) {
			Product prod = opt.get();
			prodDao.delete(prod);
			return "Product deleted from catalog";
		} else {
			throw new ProductNotFoundException("Product not found with given id");
		}
	}

	// UPDATE PRODUCT
	@Override
	public Product updateProductIncatalog(Product prod) throws ProductNotFoundException {

		Optional<Product> opt = prodDao.findById(prod.getProductId());

		if (opt.isPresent()) {
			return prodDao.save(prod);
		} else {
			throw new ProductNotFoundException("Product not found with given id");
		}
	}

	// GET ALL PRODUCTS
	@Override
	public List<Product> getAllProductsIncatalog() {
		List<Product> list = prodDao.findAll();

		if (list.size() > 0)
			return list;
		else
			throw new ProductNotFoundException("No products in catalog");
	}

	// GET PRODUCTS BY CATEGORY
	@Override
	public List<ProductDTO> getProductsOfCategory(CategoryEnum catenum) {

		List<ProductDTO> list = prodDao.getAllProductsInACategory(catenum);

		if (list.size() > 0)
			return list;
		else
			throw new CategoryNotFoundException("No products found with category: " + catenum);
	}

	// GET PRODUCTS BY STATUS
	@Override
	public List<ProductDTO> getProductsOfStatus(ProductStatus status) {

		List<ProductDTO> list = prodDao.getProductsWithStatus(status);

		if (list.size() > 0)
			return list;
		else
			throw new ProductNotFoundException("No products found with status: " + status);
	}

	// UPDATE PRODUCT QUANTITY
	@Override
	public Product updateProductQuantityWithId(Integer id, ProductDTO prodDto) {

		Optional<Product> opt = prodDao.findById(id);

		if (opt.isPresent()) {

			Product prod = opt.get();

			// update quantity
			prod.setQuantity(prod.getQuantity() + prodDto.getQuantity());

			// update status
			if (prod.getQuantity() > 0) {
				prod.setStatus(ProductStatus.AVAILABLE);
			}

			return prodDao.save(prod);

		} else {
			throw new ProductNotFoundException("No product found with this Id");
		}
	}

	// GET PRODUCTS OF A SELLER
	@Override
	public List<ProductDTO> getAllProductsOfSeller(Integer id) {

		List<ProductDTO> list = prodDao.getProductsOfASeller(id);

		if (list.size() > 0)
			return list;
		else
			throw new ProductNotFoundException("No products found for Seller ID: " + id);
	}

}
