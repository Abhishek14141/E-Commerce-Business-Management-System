package com.tka.service;

import com.tka.models.CartDTO;
import com.tka.models.CartItem;

public interface CartItemService {
	
	public CartItem createItemforCart(CartDTO cartdto);
	
}
