package com.tka.exception;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.NoHandlerFoundException;


@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(ProductNotFoundException.class)
    public ResponseEntity<ErrorDetails> productNotFound(ProductNotFoundException ex, WebRequest wr){
        ErrorDetails err = new ErrorDetails(LocalDateTime.now(), ex.getMessage(), wr.getDescription(false));
        return new ResponseEntity<>(err, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(CategoryNotFoundException.class)
    public ResponseEntity<ErrorDetails> categoryNotFound(CategoryNotFoundException ex, WebRequest wr){
        ErrorDetails err = new ErrorDetails(LocalDateTime.now(), ex.getMessage(), wr.getDescription(false));
        return new ResponseEntity<>(err, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(SellerException.class)
    public ResponseEntity<ErrorDetails> sellerExceptionHandler(SellerException ex, WebRequest wr){
        ErrorDetails err = new ErrorDetails(LocalDateTime.now(), ex.getMessage(), wr.getDescription(false));
        return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(SellerNotFoundException.class)
    public ResponseEntity<ErrorDetails> sellerNotFoundExceptionHandler(SellerNotFoundException ex, WebRequest wr){
        ErrorDetails err = new ErrorDetails(LocalDateTime.now(), ex.getMessage(), wr.getDescription(false));
        return new ResponseEntity<>(err, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(CustomerNotFoundException.class)
    public ResponseEntity<ErrorDetails> customerNotFoundExceptionHandler(CustomerNotFoundException ex, WebRequest wr){
        ErrorDetails err = new ErrorDetails(LocalDateTime.now(), ex.getMessage(), wr.getDescription(false));
        return new ResponseEntity<>(err, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(CustomerException.class)
    public ResponseEntity<ErrorDetails> customerExceptionHandler(CustomerException ex, WebRequest wr){
        ErrorDetails err = new ErrorDetails(LocalDateTime.now(), ex.getMessage(), wr.getDescription(false));
        return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(LoginException.class)
    public ResponseEntity<ErrorDetails> loginExceptionHandler(LoginException ex, WebRequest wr){
        ErrorDetails err = new ErrorDetails(LocalDateTime.now(), ex.getMessage(), wr.getDescription(false));
        return new ResponseEntity<>(err, HttpStatus.UNAUTHORIZED);
    }

    @ExceptionHandler(OrderException.class)
    public ResponseEntity<ErrorDetails> orderExceptionHandler(OrderException ex, WebRequest wr){
        ErrorDetails err = new ErrorDetails(LocalDateTime.now(), ex.getMessage(), wr.getDescription(false));
        return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(NoHandlerFoundException.class)
    public ResponseEntity<ErrorDetails> noHandlerFound(NoHandlerFoundException ex, WebRequest wr){
        ErrorDetails err = new ErrorDetails(LocalDateTime.now(), ex.getMessage(), wr.getDescription(false));
        return new ResponseEntity<>(err, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorDetails> methodArgumentNotValid(MethodArgumentNotValidException ex, WebRequest wr){
        String message = ex.getBindingResult().getFieldErrors().isEmpty()
                ? "Validation failed"
                : ex.getBindingResult().getFieldErrors().get(0).getDefaultMessage();

        ErrorDetails err = new ErrorDetails(LocalDateTime.now(), message, wr.getDescription(false));
        return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorDetails> exceptionHandler(Exception ex, WebRequest wr){
        ErrorDetails err = new ErrorDetails(LocalDateTime.now(), ex.getMessage(), wr.getDescription(false));
        return new ResponseEntity<>(err, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}

