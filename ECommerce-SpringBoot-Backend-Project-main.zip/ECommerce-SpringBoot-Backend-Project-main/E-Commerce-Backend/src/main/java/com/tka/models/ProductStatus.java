package com.tka.models;

public enum ProductStatus {
	
	AVAILABLE,OUTOFSTOCK
	
	
}
