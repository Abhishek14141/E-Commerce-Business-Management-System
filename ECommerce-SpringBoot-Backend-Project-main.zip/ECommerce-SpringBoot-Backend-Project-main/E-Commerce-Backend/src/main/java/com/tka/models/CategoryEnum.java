package com.tka.models;


public enum CategoryEnum {
	
	BOOKS,FASHION,ELECTRONICS,FURNITURE,GROCERIES

}
