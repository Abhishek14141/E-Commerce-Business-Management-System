package com.tka.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tka.models.CartItem;

public interface CartItemDao extends JpaRepository<CartItem, Integer>{

}
