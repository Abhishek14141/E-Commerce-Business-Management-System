package com.tka.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.tka.models.CategoryEnum;
import com.tka.models.Product;
import com.tka.models.ProductDTO;
import com.tka.models.ProductStatus;

@Repository
public interface ProductDao extends JpaRepository<Product, Integer> {

	@Query("select new com.tka.models.ProductDTO(p.productName, p.manufacturer, p.price, p.quantity) "
			+ "from Product p where p.category = :catenum")
	List<ProductDTO> getAllProductsInACategory(@Param("catenum") CategoryEnum catenum);

	@Query("select new com.tka.models.ProductDTO(p.productName, p.manufacturer, p.price, p.quantity) "
			+ "from Product p where p.status = :status")
	List<ProductDTO> getProductsWithStatus(@Param("status") ProductStatus status);

	@Query("select new com.tka.models.ProductDTO(p.productName, p.manufacturer, p.price, p.quantity) "
			+ "from Product p where p.seller.sellerId = :id")
	List<ProductDTO> getProductsOfASeller(@Param("id") Integer id);
}
